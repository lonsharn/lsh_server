// automatically generated, do not modify

package MyGame.Example;

public final class Color {
  private Color() { }
  public static final byte Red = 1;
  public static final byte Green = 2;
  public static final byte Blue = 8;

  private static final String[] names = { "Red", "Green", "", "", "", "", "", "Blue", };

  public static String name(int e) { return names[e - Red]; }
};

