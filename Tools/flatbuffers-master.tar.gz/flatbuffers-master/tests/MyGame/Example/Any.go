// automatically generated, do not modify

package Example

const (
	AnyNONE = 0
	AnyMonster = 1
	AnyTestSimpleTableWithEnum = 2
)
