../flatc -c -j -n -g -b -p --gen-mutable --no-includes monster_test.fbs monsterdata_test.json
../flatc -b --schema monster_test.fbs
