// automatically generated, do not modify

namespace MyGame.Example
{

public enum Any : byte
{
 NONE = 0,
 Monster = 1,
 TestSimpleTableWithEnum = 2,
};


}
