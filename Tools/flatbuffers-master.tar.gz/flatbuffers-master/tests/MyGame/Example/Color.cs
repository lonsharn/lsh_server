// automatically generated, do not modify

namespace MyGame.Example
{

public enum Color : sbyte
{
 Red = 1,
 Green = 2,
 Blue = 8,
};


}
